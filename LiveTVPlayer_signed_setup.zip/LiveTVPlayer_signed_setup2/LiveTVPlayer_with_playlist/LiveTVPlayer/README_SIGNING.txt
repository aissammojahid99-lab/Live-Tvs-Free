LiveTVPlayer — How to build a SIGNED release APK
------------------------------------------------
1) Create a keystore
   keytool -genkeypair -v -keystore mykeystore.jks -alias myalias -keyalg RSA -keysize 2048 -validity 36500

2) Put signing values in gradle.properties (recommended: ~/.gradle/gradle.properties)
   keystorePath=/absolute/path/to/mykeystore.jks
   keystorePassword=YOUR_PASSWORD
   keyAlias=myalias
   keyPassword=YOUR_KEY_PASSWORD

3) In Android Studio:
   - Select Build Variant 'release'
   - Build > Build Bundle(s)/APK(s) > Build APK(s)
   Output: app/build/outputs/apk/release/app-release.apk

4) Or CLI:
   ./gradlew assembleRelease
