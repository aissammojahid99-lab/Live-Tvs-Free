package com.example.livetvplayer

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var recycler: RecyclerView
    private lateinit var adapter: ChannelAdapter
    private val channels = mutableListOf<Channel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val playlistUrl = findViewById<EditText>(R.id.playlistUrl)
        val loadButton = findViewById<Button>(R.id.loadButton)

        recycler = findViewById(R.id.recycler)
        recycler.layoutManager = LinearLayoutManager(this)
        adapter = ChannelAdapter(channels) { chan ->
            val i = Intent(this, PlayerActivity::class.java)
            i.putExtra("name", chan.name)
            i.putExtra("url", chan.url)
            startActivity(i)
        }
        recycler.adapter = adapter

        // Load bundled sample playlist into list on first launch
        loadBundledPlaylist()

        loadButton.setOnClickListener {
            val url = playlistUrl.text.toString().trim()
            if (url.isNotEmpty()) {
                Thread {
                    try {
                        val fetched = fetchText(url)
                        val parsed = M3UParser.parse(fetched)
                        runOnUiThread {
                            channels.clear()
                            channels.addAll(parsed)
                            adapter.notifyDataSetChanged()
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }.start()
            }
        }
    }

    private fun loadBundledPlaylist() {
        try {
            val input = assets.open("playlist.m3u")
            val txt = input.bufferedReader().use { it.readText() }
            val parsed = M3UParser.parse(txt)
            channels.clear()
            channels.addAll(parsed)
            adapter.notifyDataSetChanged()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun fetchText(link: String): String {
        val url = URL(link)
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 10000
        conn.readTimeout = 15000
        conn.requestMethod = "GET"
        conn.connect()
        val reader = BufferedReader(InputStreamReader(conn.inputStream))
        val sb = StringBuilder()
        var line: String? = reader.readLine()
        while (line != null) {
            sb.append(line).append('\n')
            line = reader.readLine()
        }
        reader.close()
        conn.disconnect()
        return sb.toString()
    }
}
