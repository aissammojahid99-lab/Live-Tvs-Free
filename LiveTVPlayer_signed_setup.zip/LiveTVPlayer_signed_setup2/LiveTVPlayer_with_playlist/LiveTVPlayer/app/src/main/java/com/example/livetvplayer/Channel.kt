package com.example.livetvplayer

data class Channel(
    val name: String,
    val url: String
)
