package com.example.livetvplayer

object M3UParser {
    // Very basic M3U / EXTINF parser
    fun parse(text: String): List<Channel> {
        val lines = text.lines()
        val out = mutableListOf<Channel>()
        var currentName: String? = null
        for (i in lines.indices) {
            val line = lines[i].trim()
            if (line.startsWith("#EXTINF", ignoreCase = true)) {
                // Extract title after comma
                val idx = line.lastIndexOf(',')
                currentName = if (idx >= 0 && idx < line.length - 1) {
                    line.substring(idx + 1).trim()
                } else {
                    "Channel"
                }
            } else if (line.isNotEmpty() && !line.startsWith("#")) {
                val url = line
                val name = currentName ?: "Channel"
                out.add(Channel(name, url))
                currentName = null
            }
        }
        return out
    }
}
