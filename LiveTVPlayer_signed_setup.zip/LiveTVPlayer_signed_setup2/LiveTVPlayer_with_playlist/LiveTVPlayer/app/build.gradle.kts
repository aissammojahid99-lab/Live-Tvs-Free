plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

\1

// Read signing values from gradle.properties (do NOT hardcode secrets)
val keystorePath: String? by project
val keystorePassword: String? by project
val keyAlias: String? by project
val keyPassword: String? by project

signingConfigs {
    create("release") {
        // Only configure if properties exist
        if (keystorePath != null && keystorePassword != null && keyAlias != null && keyPassword != null) {
            storeFile = file(keystorePath!!)
            storePassword = keystorePassword
            this.keyAlias = keyAlias!!
            this.keyPassword = keyPassword
            enableV1Signing = true
            enableV2Signing = true
            enableV3Signing = true
        }
    }
}

    namespace = "com.example.livetvplayer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.livetvplayer"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables { useSupportLibrary = true }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.2.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")

    // ExoPlayer
    implementation("com.google.android.exoplayer:exoplayer:2.19.1")

    // Lifecycle (optional)
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
}
